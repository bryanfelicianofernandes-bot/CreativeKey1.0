# Creative Key — Minecraft Java 26.1.2 / Fabric

Projeto-fonte de um mod que alterna entre Criativo e Sobrevivência com a tecla **G**.

## O que faz
- No mundo individual, a tecla G envia o comando `/creativekey` ao servidor integrado.
- O comando alterna entre Criativo e Sobrevivência sem exigir cheats/OP, porque o mod registra deliberadamente esse comando sem requisito de permissão.
- Em multiplayer, o servidor precisa ter o mod instalado. Não permite alterar o modo num servidor que não tenha o mod.

## Dependências / compilação
- Minecraft Java 26.1.2
- Fabric Loader 0.18.4 ou compatível
- Fabric API 0.149.1+26.1.2
- Java JDK 25
- Gradle compatível com Fabric Loom 1.15.2

Execute na pasta do projeto:

```sh
gradle build --no-daemon
```

O JAR de produção deverá aparecer em `build/libs/creativekey-1.0.0.jar`.

## Instalação
Copie o JAR gerado para a pasta `mods` da instância Fabric 26.1.2 do MojoLauncher. Fabric API também precisa estar na pasta `mods`. Abra um mundo individual e pressione **G**. A tecla pode ser alterada em Opções → Controles → Teclas.

## Aviso honesto
Este projeto foi montado como código-fonte, mas não foi compilado nem testado neste ambiente. Minecraft 26.1.2 requer Java 25; o ambiente de preparação disponível só tinha Java 21 e não tinha Gradle instalado. Se a compilação acusar diferenças de API nessa versão, o código precisará ser ajustado com base no erro.
