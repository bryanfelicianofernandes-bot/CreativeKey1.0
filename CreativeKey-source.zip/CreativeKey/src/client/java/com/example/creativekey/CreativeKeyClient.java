package com.example.creativekey;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

public final class CreativeKeyClient implements ClientModInitializer {
    private static KeyMapping toggleKey;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
            "key.creativekey.toggle",
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_G,
            "key.categories.misc"
        ));

        ClientTickEvents.END_CLIENT_TICK.register((Minecraft client) -> {
            while (toggleKey.consumeClick()) {
                if (client.player != null && client.getConnection() != null) {
                    // Send a normal server command so the integrated server performs the mode change.
                    client.player.connection.sendCommand("creativekey");
                }
            }
        });
    }
}
