package com.example.creativekey;

import com.mojang.brigadier.Command;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.Commands;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.GameType;
import net.minecraft.network.chat.Component;

public final class CreativeKeyMod implements ModInitializer {
    @Override
    public void onInitialize() {
        // This command is deliberately available without operator permission.
        // In singleplayer, it runs on the integrated server. On multiplayer,
        // the server must also have this mod installed for the command to exist.
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            dispatcher.register(Commands.literal("creativekey").executes(context -> {
                ServerPlayer player = context.getSource().getPlayerOrException();
                GameType current = player.gameMode.getGameModeForPlayer();
                GameType next = current == GameType.CREATIVE ? GameType.SURVIVAL : GameType.CREATIVE;
                player.setGameMode(next);
                player.sendSystemMessage(Component.literal(
                    next == GameType.CREATIVE ? "Creative Key: Criativo ativado!" : "Creative Key: Sobrevivencia ativada!"
                ));
                return Command.SINGLE_SUCCESS;
            }))
        );
    }
}
